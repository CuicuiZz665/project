# AGENTS.md

JS subdirectory guide for agents working under `js/`. This project is a static, build-free admin prototype. Do not add Node, npm, bundlers, transpilers, framework runtimes, or ES module imports. All JavaScript must remain browser-native and loadable by opening `index.html` directly.

## Mandatory Documentation Sync

- Any change to a file in `js/` must include a same-change review of this `js/AGENTS.md`.
- If the JS change adds, removes, renames, reorders, or changes the responsibility, public API, dependencies, DOM hooks, or data shape of any `js/*.js` file, update this document in the same patch.
- If the JS change does not require a documentation edit, state why in the handoff or final note.
- When adding a new JS file, document it here first or in the same patch, then add it to `js/bootstrap.js` in dependency order.

## Local JS Rules

- Each JS file must use an IIFE and register shared/public members onto `window.AdminApp`.
- Keep `js/bootstrap.js` as the only script chain entry. Do not change `index.html` to load individual feature files directly.
- Load order matters. A file may only depend on modules listed before it in `bootstrap.js`.
- Prefer constructor injection for shared services such as `toast` and `confirm`.
- Keep business data in `mock-data.js`; Managers and Modals may keep temporary UI state only.
- Prefer stable `id` and `data-*` DOM hooks. When a hook changes, update the related `index.html`, CSS, JS, and this document together.
- Use `app.utils.escapeHtml` for user-visible dynamic text. Use controlled `innerHTML` only for known snippets such as tags, pills, table rows, pagination controls, and modal fragments.
- Keep view/list behavior in Managers, form/overlay behavior in Modals, and navigation/startup behavior in `app-shell.js` / `app.js`.

## Load Order

```text
bootstrap.js
|-- namespace.js
|-- utils.js
|-- pagination.js
|-- mock-data.js
|-- toast.js
|-- confirm-dialog.js
|-- rule-modal.js
|-- rule-manager.js
|-- delivery-modal.js
|-- delivery-manager.js
|-- app-shell.js
`-- app.js
```

When changing this order, verify every dependency below still loads before its consumer.

## File Responsibilities

### `bootstrap.js`

- Role: dynamic script loader and the only JavaScript entry loaded by `index.html`.
- Registers: nothing on `window.AdminApp`; it injects script tags in sequence.
- Depends on: browser DOM APIs only.
- Consumers: `index.html`.
- Change when: adding/removing/renaming JS modules or correcting dependency order.
- Validate: every listed file exists, and the browser console has no script load failures when `index.html` is opened directly.

### `namespace.js`

- Role: creates or reuses the global namespace.
- Registers: `window.AdminApp`.
- Depends on: no local modules.
- Consumers: every later JS file.
- Change when: the global namespace strategy changes.
- Avoid: adding feature logic here.

### `utils.js`

- Role: shared low-level DOM and HTML escaping helpers.
- Registers: `app.dom.$`, `app.dom.$$`, `app.utils.escapeHtml`.
- Depends on: `namespace.js`.
- Consumers: shared services, Managers, and Modals.
- Change when: a helper is genuinely shared by multiple modules or a shared helper has a defect.
- Regression scope: all render paths and event bindings that use `$`, `$$`, or `escapeHtml`.

### `pagination.js`

- Role: reusable pagination renderer and interaction binder for list views.
- Registers: `app.renderPagination({ container, total, page, pageSize, pageSizes, onChange })`.
- Depends on: `namespace.js`.
- Consumers: `RuleManager.render()` and `DeliveryManager.render()`.
- Behavior: writes pagination summary, page buttons, previous/next controls, page-size select, and returns `{ page, pageSize, totalPages, start, end }`.
- Change when: list pagination UX, page sizing, or pagination markup/classes change.
- Regression scope: point rule list pagination and delivery list pagination.

### `mock-data.js`

- Role: centralized mock business data and static options for the prototype.
- Registers: `app.mockData.breadcrumbs`, `app.mockData.rules`, `app.mockData.deliveries`, `app.mockData.cascaderOptions`.
- Depends on: `namespace.js`.
- Consumers: `app.js`, Managers, Modals, and detail displays.
- Data shape:
  - Rule rows use fields such as `id`, `internalName`, `externalName`, `triggerEvent`, `cyclePeriod`, `rewardXp`, `rewardDrop`, `taskType`, `timeRange`, `status`, `canEdit`.
  - Delivery rows use fields such as `id`, `key`, `name`, `object`, `objectDetail`, `method`, `count`, `status`, `start`, `end`, `event`, `param`, `operator`.
  - Cascader options are keyed by delivery type and include `text`, `second`, and `third`.
- Change when: initial business examples, option lists, default breadcrumbs, or data fields change.
- Regression scope: list rendering, modal prefill, save output, filters, and detail drawer fields that read changed data.

### `toast.js`

- Role: shared transient notification service.
- Registers: `app.Toast`.
- Depends on: `app.dom.$`.
- Consumers: `app.js` creates one instance and injects it into Managers, Modals, and AppShell.
- DOM hooks: `#toast`.
- Change when: toast behavior, selector, timing, or shared notification API changes.
- Regression scope: all toast trigger points in rule, delivery, navigation, import/export/clear, upload, search, reset, and status actions.

### `confirm-dialog.js`

- Role: shared confirmation dialog service.
- Registers: `app.ConfirmDialog`.
- Depends on: `app.dom.$`.
- Consumers: `app.js` creates one instance and injects it into Managers and Modals.
- DOM hooks: `#confirmOverlay`, `#confirmTitle`, `#confirmBody`, `#closeConfirmBtn`, `#cancelConfirmBtn`, `#okConfirmBtn`.
- Public methods: `init()`, `ask(title, body, action)`, `close()`.
- Change when: shared confirmation lifecycle, copy slots, buttons, or callback behavior changes.
- Regression scope: rule save/enable/disable and delivery save/enable/void confirmations.

### `rule-modal.js`

- Role: point rule add/edit/copy modal, including dynamic form sections and validation.
- Registers: `app.RuleModal`.
- Depends on: `app.dom.$`; receives `state`, `toast`, `confirm`, and `onSave` by constructor injection.
- Consumer: `RuleManager`.
- DOM scope: `#ruleOverlay` and rule modal controls such as `#internalName`, `#taskType`, `#rewardXp`, `#rewardDrop`, `#triggerEvent`, `#eventParam`, `#accountType`, `#jumpType`, `#mediaMode`, `#languageTabs`, `#cyclePeriod`, `#startTime`, `#endTime`.
- Public methods: `init()`, `open(mode, rule)`, `close()`, `collectForm()`, `save()`, `syncTriggerDefaults()`, `syncJumpType()`, `syncMediaMode()`, `syncCyclePeriod()`, `renderLanguageTabs()`.
- Behavior: pre-fills modal data, simulates upload, manages language tabs, changes fields based on trigger/jump/media/cycle choices, validates XP/Drop, and asks for confirmation before saving.
- Change when: rule form fields, validation, prefill, copy/edit/add behavior, dynamic visibility, language handling, or collected rule data changes.
- Regression scope: add, edit, copy, reward validation, dynamic trigger fields, cycle date visibility, language tabs, upload mock, and save confirmation.

### `rule-manager.js`

- Role: point rule list view controller.
- Registers: `app.RuleManager`.
- Depends on: `app.dom.$`, `app.dom.$$`, `app.utils.escapeHtml`, `app.renderPagination`, `app.RuleModal`.
- Consumer: `app.js`.
- DOM scope: `#rulesBody`, `#pagination`, `#ruleKeyword`, `#statusFilter`, `#columnPanel`, `#addRuleBtn`, `#columnBtn`, `#searchBtn`, `#resetBtn`, sortable table headers, and `[data-toggle-column]`.
- Public methods: `init()`, `render()`, `filteredRules()`, `syncColumnVisibility()`, `handleRuleAction(event)`, `saveRule(data, editingId, title)`.
- Behavior: owns rule list state, search/reset, status filter, sorting, pagination, column visibility, row actions, status enable/disable, and integration with `RuleModal`.
- Change when: point rule table fields, filters, sorting, pagination, column settings, row actions, or rule save behavior changes.
- Regression scope: search, reset, sorting, pagination, column settings, enable/disable, add/edit/copy save results.

### `delivery-modal.js`

- Role: delivery create/edit modal, cascader object selection, automatic/manual form switching, and mocked import/export/clear actions.
- Registers: `app.DeliveryModal`.
- Depends on: `app.dom.$`, `app.dom.$$`, `app.utils.escapeHtml`; receives `data`, `options`, `toast`, `confirm`, and `onSave` by constructor injection.
- Consumer: `DeliveryManager`.
- DOM scope: `#createMask`, `#deliveryModalTitle`, `#deliveryNameInput`, `#deliveryCascader`, `#deliveryValue`, `#secondCol`, `#thirdCol`, `#couponBox`, `#bonusBox`, `#pointsBox`, `#deliveryMethod`, `#autoSection`, `#manualSection`, `#eventSelect`, `#paramLabel`, `#probabilityInput`, `#pointValueLabel`, date inputs, count/amount inputs, and manual user controls.
- Public methods: `init()`, `open(mode, item)`, `close()`, `renderCascader(type, secondIndex, thirdIndex)`, `resetSelection()`, `selectedObject()`, `confirmDelivery()`, `handleCascaderClick(event)`, `syncEventParam()`, `syncDeliveryMethod()`.
- Behavior: pre-fills delivery fields, renders two/three-level object cascader, toggles automatic/manual sections, assembles delivery list/detail data, escapes dynamic pill values, and confirms before saving.
- Change when: delivery form fields, cascader data consumption, automatic/manual behavior, save payload, import/export/clear mocks, or modal lifecycle changes.
- Regression scope: create, edit, cascader selection, automatic/manual switch, event parameter copy, import/export/clear mocks, and save confirmation.

### `delivery-manager.js`

- Role: delivery list view controller and detail drawer controller.
- Registers: `app.DeliveryManager`.
- Depends on: `app.dom.$`, `app.utils.escapeHtml`, `app.renderPagination`, `app.DeliveryModal`.
- Consumer: `app.js`.
- DOM scope: `#deliveryBody`, `#deliveryPagination`, `#deliveryKeyword`, `#deliveryObjectFilter`, `#deliveryStatusFilter`, `#openCreate`, `#moreDeliveryFilter`, `#searchDeliveryBtn`, `#resetDeliveryBtn`, `#closeDetail`, `#drawerMask`, `#detailDrawer`, and detail field ids.
- Public methods: `init()`, `render()`, `handleAction(event)`, `save(itemData, editingId)`, `showDetail(id)`, `hideDetail()`.
- Behavior: owns delivery list state, search/reset, object/status filters, pagination, create/edit modal integration, enable/void actions, and detail drawer display.
- Change when: delivery table fields, filters, action rules, save behavior, or detail drawer content changes.
- Regression scope: search, reset, pagination, create/edit results, enable, void, detail drawer open/close, and detail field display.

### `app-shell.js`

- Role: page shell controller for sidebar groups, page switching, active nav state, breadcrumbs, and business module initialization.
- Registers: `app.AppShell`.
- Depends on: `app.dom.$`, `app.dom.$$`; receives breadcrumbs, toast, ruleManager, and deliveryManager by constructor injection.
- Consumer: `app.js`.
- DOM scope: `[data-nav-toggle]`, `[data-page]`, `[data-nav-group]`, `#rulesView`, `#deliveryView`, `#breadcrumb`, `#columnPanel`.
- Public methods: `init()`, `switchPage(page)`, `toggleGroup(button)`, `syncNavigation(page)`.
- Behavior: initializes rule and delivery managers, switches views, syncs sidebar active/expanded state, updates breadcrumbs, closes column panel on navigation, and shows navigation toasts.
- Change when: navigation structure, page ids, breadcrumb behavior, active state rules, or startup order changes.
- Regression scope: rules/delivery navigation, breadcrumbs, active nav state, expanded groups, hidden views, and manager initialization.

### `app.js`

- Role: application composition root.
- Registers: nothing new; it starts the app after DOM readiness.
- Depends on: all previous modules in `bootstrap.js`.
- Behavior: creates shared `Toast` and `ConfirmDialog`, creates `RuleManager` and `DeliveryManager` with mock data and shared services, creates `AppShell`, then calls `confirm.init()` and `shell.init()`.
- Change when: dependency injection wiring, startup order, shared service lifetime, or root data source changes.
- Validate: app still starts from direct `index.html` open, both business modules initialize once, and shared services are reused rather than recreated inside modules.

## Change Entry Points

```text
Shared namespace/helpers
|-- namespace.js
|-- utils.js
`-- Update all consumers if public helper names change

Pagination shared by lists
|-- pagination.js
|-- rule-manager.js
`-- delivery-manager.js

Mock data or option shape
|-- mock-data.js
|-- Related Manager render/filter/detail code
`-- Related Modal prefill/collect/save code

Point rule list
|-- rule-manager.js
|-- rule-modal.js only if modal save/prefill is affected
`-- index.html / css/tables.css when DOM or styles change

Point rule modal
|-- rule-modal.js
|-- mock-data.js only if rule data shape changes
`-- index.html / css/modals.css when DOM or styles change

Delivery list and detail drawer
|-- delivery-manager.js
|-- delivery-modal.js only if save payload is affected
`-- index.html / css/tables.css / css/modals.css when DOM or styles change

Delivery create/edit modal
|-- delivery-modal.js
|-- mock-data.js for cascader options or data shape
`-- index.html / css/modals.css when DOM or styles change

Navigation/startup
|-- app-shell.js
|-- app.js
`-- bootstrap.js only if module order changes
```

## Validation Checklist for JS Changes

```text
Static checks
|-- index.html loads only js/bootstrap.js
|-- Every file listed in bootstrap.js exists
|-- New or changed modules register onto window.AdminApp when they expose app-level APIs
|-- bootstrap.js order satisfies dependencies
`-- Browser console has no script load failures

Module checks
|-- Changed Manager: test filters, actions, pagination, empty states, and related modal integration
|-- Changed Modal: test open, prefill, dynamic fields, validation, close, confirm, and save result
|-- Changed mock-data: test all renders, filters, prefills, and details that consume changed fields
|-- Changed pagination.js: test both rule and delivery pagination
|-- Changed app-shell.js/app.js: test navigation and one-time module initialization
`-- Changed shared service/helper: regress all consumers listed above

Documentation checks
|-- This js/AGENTS.md reflects changed file responsibilities and APIs
|-- New DOM hooks are documented in the relevant file section
|-- New data fields are documented in mock-data.js and consumer sections
`-- If no doc edit was needed for a JS change, the final note says why
```
