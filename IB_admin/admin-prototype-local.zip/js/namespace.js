window.AdminApp = window.AdminApp || {};
