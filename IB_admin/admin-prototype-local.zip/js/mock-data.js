(function registerMockData(app) {
  app.mockData = {
    breadcrumbs: {
      rules: "市场活动 &gt; 积分 &gt; <strong>积分获取设置</strong>",
      delivery: "市场活动 &gt; 投递管理 &gt; <strong>投递列表</strong>"
    },
    rules: [
      { id: 1, internalName: "首次签到连续5天", externalName: "英语: 首次签到连续5天", triggerEvent: "首次连续签到", cyclePeriod: "不限", rewardXp: 33, rewardDrop: 0, taskType: "全部", timeRange: "-", status: "启用", canEdit: false },
      { id: 2, internalName: "连续签到5天", externalName: "英语: 连续签到5天", triggerEvent: "连续签到", cyclePeriod: "不限", rewardXp: 555, rewardDrop: 0, taskType: "全部", timeRange: "-", status: "启用", canEdit: false },
      { id: 3, internalName: "真实账号交易奖励", externalName: "英语: First trade reward", triggerEvent: "开仓", cyclePeriod: "按天", rewardXp: 0, rewardDrop: 100, taskType: "新手任务", timeRange: "-", status: "启用", canEdit: true },
      { id: 4, internalName: "学习K线图", externalName: "英语: Learn candlestick", triggerEvent: "手动触发", cyclePeriod: "不限", rewardXp: 150, rewardDrop: 100, taskType: "新手任务", timeRange: "-", status: "待启用", canEdit: true },
      { id: 5, internalName: "交易手续费奖励", externalName: "英语: Trading fee reward", triggerEvent: "手续费", cyclePeriod: "按天", rewardXp: 0, rewardDrop: 300, taskType: "全部", timeRange: "-", status: "禁用", canEdit: true },
      { id: 6, internalName: "邀请好友注册", externalName: "英语: Invite friends", triggerEvent: "手动触发", cyclePeriod: "不限", rewardXp: 80, rewardDrop: 0, taskType: "全部", timeRange: "-", status: "启用", canEdit: true },
      { id: 7, internalName: "首笔跟单", externalName: "英语: First copy trade", triggerEvent: "跟单", cyclePeriod: "不限", rewardXp: 0, rewardDrop: 150, taskType: "新手任务", timeRange: "-", status: "待启用", canEdit: true },
      { id: 8, internalName: "学习杠杆倍数", externalName: "英语: Learn leverage", triggerEvent: "手动触发", cyclePeriod: "不限", rewardXp: 150, rewardDrop: 0, taskType: "新手任务", timeRange: "-", status: "启用", canEdit: true }
    ],
    deliveries: [
      { id: 1, key: "coupon", name: "测4", object: "抹亏券-测试待激活展示", objectDetail: "优惠券 -> 抹亏券 -> 测试待激活展示", method: "人工", count: "0", status: "未启用", start: "2026-08-28 00:00", end: "2026-09-05 00:00", event: "手动发送优惠券", param: '<span class="pill">指定用户：870206426</span>', operator: "Bella" },
      { id: 2, key: "bonus", name: "奖励账户投递", object: "奖励-统一交易账户奖金", objectDetail: "奖励 -> 统一交易账户", method: "人工", count: "25", status: "未启用", start: "2026-09-01 00:00", end: "2026-09-15 00:00", event: "大转盘", param: '<span class="pill gold">金额：100</span><span class="pill gold">发放数量（份）：25</span><span class="pill gold">中奖概率：15%</span>', operator: "Amy" },
      { id: 3, key: "points", name: "积分大转盘投递", object: "积分-XP", objectDetail: "积分 -> XP", method: "自动", count: "128", status: "启用", start: "2026-09-01 00:00", end: "2026-09-30 00:00", event: "大转盘", param: '<span class="pill blue">XP：100</span><span class="pill blue">发放数量（份）：1</span><span class="pill blue">中奖概率：30%</span>', operator: "Bella" }
    ],
    cascaderOptions: {
      coupon: { text: "优惠券", second: ["抹亏券", "交易返现券", "手续费减免券"], third: ["测试待激活展示", "正式测试抹亏券", "loss-recover-10"] },
      bonus: { text: "奖励", second: ["统一交易账户", "投资账户", "模拟账户", "赠金账户"], third: [] },
      points: { text: "积分", second: ["XP", "Drop"], third: [] }
    }
  };
})(window.AdminApp);
